export const REFRESH_INTERVAL = 1000; // Milliseconds
